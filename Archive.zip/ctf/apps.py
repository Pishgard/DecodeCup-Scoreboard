from django.apps import AppConfig


class CtfConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ctf'
    verbose_name = "جدول امتیازات"
